document.getElementById('goback').addEventListener('click', function() {
    window.history.back();
  });