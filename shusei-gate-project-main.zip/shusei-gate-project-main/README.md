# ShuSei Gate Project

This is a group assignment for Y1S1, a webapp that handles the sales of ticketing for events hosted at our stadium / venue.
